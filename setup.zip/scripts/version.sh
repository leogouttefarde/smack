#! /bin/bash

md5=($(md5sum ~/setup.zip))
echo "Setup MD5 : $md5"

