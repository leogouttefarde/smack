#! /bin/bash
# Updates the setup files everywhere

DIR=$(cd "$(dirname "$0")" && pwd)
. "$DIR"/utility.sh

setup_res

