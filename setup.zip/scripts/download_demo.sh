#!/usr/bin/env bash

wget -O ~/apps_demo.zip https://github.com/leogouttefarde/smack/blob/master/apps_demo.zip?raw=true
wget -O ~/test-small.csv https://github.com/leogouttefarde/smack/blob/master/test-small.csv?raw=true

unzip ~/apps_demo.zip -d /home/xnet