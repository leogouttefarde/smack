#!/usr/bin/env bash
if [ $# -ge 1 ]; then

echo lol

else

echo haha

fi

