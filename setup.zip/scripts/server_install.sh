# server installation script that installs everything for a single machine


# configure hosts
~/scripts/declare_hosts.sh


