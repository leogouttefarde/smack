# server installation script that installs everything for a single machine


# configure hosts
./declare_hosts.sh


