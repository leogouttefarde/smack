import com.datastax.spark.connector._
import com.datastax.spark.connector.cql._ 
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
/*import com.datastax.spark.connector.cql.{RegularColumn, ColumnDef, PartitionKeyColumn, TableDef}
import com.datastax.spark.connector.types.{TimestampType, IntType, VarCharType}
import com.datastax.spark.connector.cql.CassandraConnector*/

object SimpleApp {
  def main(args: Array[String]) {
  	val conf = new SparkConf(true).setAppName("Simple Application")
    val sc = new SparkContext(conf)

	val csv = sc.textFile("test.csv")
	val header=csv.first()
	val lignes=csv.filter(l => l!=header)
	val args=header.split(",").mkString("\"", "\",\"", "\"")
	val rows=lignes.map(row => row.split(","))
	val collection = rows.map(row => (row(0),row(1),row(2),row(3),row(4),row(5),row(6),row(7),row(8),row(9),row(10)))

	/*val column1 = ColumnDef("medallion", PartitionKeyColumn, VarCharType)
	val column2 = ColumnDef("hack_license", RegularColumn, VarCharType)
	val column3 = ColumnDef("vendor_id", RegularColumn, VarCharType)
	val column4 = ColumnDef("pickup_datetime", RegularColumn, TimestampType)
	val column5 = ColumnDef("payment_type", RegularColumn, VarCharType)
	val column6 = ColumnDef("fare_amount", RegularColumn, VarCharType)
	val column7 = ColumnDef("surcharge", RegularColumn, VarCharType)
	val column8 = ColumnDef("mta_tax", RegularColumn, VarCharType)
	val column9 = ColumnDef("tip_amount", RegularColumn, VarCharType)
	val column10 = ColumnDef("tolls_amount", RegularColumn, VarCharType)
	val column11 = ColumnDef("total_amount", RegularColumn, VarCharType)*/
	val cx = com.datastax.spark.connector.cql.CassandraConnector(sc.getConf)
	cx.withSessionDo ( session => session.execute("CREATE KEYSPACE test WITH replication={'class':'SimpleStrategy', 'replication_factor':1}"))
	cx.withSessionDo ( session => session.execute("CREATE TABLE test.trips (medallion varchar PRIMARY KEY,hack_license varchar,vendor_id varchar,pickup_datetime varchar,payment_type varchar,fare_amount varchar, surcharge varchar, mta_tax varchar,tip_amount varchar, tolls_amount varchar,total_amount varchar)"))
	collection.saveToCassandra("test", "trips")
	sc.stop()
  }
}


//val cx = CassandraConnector(sc.getConf)
//cx.withSessionDo ( session => session.execute("CREATE KEYSPACE test WITH replication={'class':'SimpleStrategy', 'replication_factor':1}"))
//cx.withSessionDo ( session => session.execute("CREATE TABLE test.trips (medallion varchar PRIMARY KEY,hack_license varchar,vendor_id varchar,pickup_datetime varchar,payment_type varchar,fare_amount varchar, surcharge varchar, mta_tax varchar,tip_amount varchar, tolls_amount varchar,total_amount varchar)"))


//case class Trip(medallion :String ,hack_license :String,vendor_id :String,pickup_datetime :String,payment_type :String,fare_amount :String, surcharge :String, mta_tax :String,tip_amount :String, tolls_amount :String,total_amount :String)

/*def convert(a:Array[String]):Trip={
	var (medallion, hack_license, vendor_id, pickup_datetime, payment_type, fare_amount, surcharge, mta_tax, tip_amount, tolls_amount, total_amount)=a.split(",").mkString("\"", "\",\"", "\"");
	return new Trip(medallion, hack_license, vendor_id, pickup_datetime, payment_type, fare_amount, surcharge, mta_tax, tip_amount, tolls_amount, total_amount);
	
}*/
//val collection = rows.map(row => (row(0),row(1),row(2),row(3),row(4),row(5),row(6),row(7),row(8),row(9),row(10)))

//rows.saveToCassandra("test", "trips", SomeColumns(args))


//val filtred_trips = sc.cassandraTable(“test”, “trips”).select(“*").where(“timestamps >= '2013-01-10 00:00:00'”)

//println(filtred_trips.foreach(println))






//./spark-shell   --packages datastax:spark-cassandra-connector:2.0.0-M2-s_2.11
//sudo ../spark-2.0.2-bin-hadoop2.7/bin/spark-submit --packages datastax:spark-cassandra-connector:2.0.0-M2-s_2.11  --class "SimpleApp" --master mesos://zk://server-1:2181/mesos target/scala-2.11/simple-project_2.11-1.0.jar

