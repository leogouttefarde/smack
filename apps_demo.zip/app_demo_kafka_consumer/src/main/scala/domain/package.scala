
package object domain {
  import java.util.Date
  import java.text.SimpleDateFormat
  case class Activity(medallion: String,
                      hack_license: String,
                      vendor_id: String,
                      pickup_datetime: String,
                      payment_type: String,
                      fare_amount: Float,
                      surcharge: Float,
                      mta_tax: Float,
                      tip_amount: Float,
                      tolls_amount: Float,
                      total_amount: Float
                     )
}
