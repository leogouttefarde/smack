//Don't forget to launch the consumer before the producer
import org.apache.kafka.clients.consumer.{ KafkaConsumer, ConsumerConfig, ConsumerRecord }
import org.apache.kafka.common.TopicPartition
import java.util.HashMap
import java.util.Collection
import java.util.List
import java.util.{ Arrays, Properties }
import scala.collection.JavaConversions._
import scala.util.Random
import java.util.{ Collections, Properties }
//import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql._

import com.datastax.spark.connector._
import com.datastax.spark.connector.cql._ 
import org.apache.spark.sql.{SaveMode, SQLContext}
import org.apache.spark.SparkFiles
import domain._

object ConsumerToSpark {
  def main(args: Array[String]): Unit = {
    
    val kafkaBrokers = "213.32.72.245:31000"

    val topic = "trips"

    /******* Config Consumer *******/
    val props = new HashMap[String, Object]()
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBrokers)
    props.put(ConsumerConfig.GROUP_ID_CONFIG, "test" + System.currentTimeMillis())
    props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")
    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest")
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer")
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer")
    props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, "0") //ensure we have no temporal batching


    // get spark configuration
    val conf = new SparkConf().setAppName("Test with Spark")
	// setup spark context
    val sc = new  SparkContext(conf)
    implicit val sqlContext = new SQLContext(sc)

    import org.apache.spark.sql.functions._
    import sqlContext.implicits._


    val cx = com.datastax.spark.connector.cql.CassandraConnector(sc.getConf)
    cx.withSessionDo ( session => session.execute("CREATE KEYSPACE test WITH replication = {'class': 'NetworkTopologyStrategy', '202':3,'32':3}  AND durable_writes = true"))
    cx.withSessionDo ( session => session.execute("CREATE TABLE test.trips (medallion text PRIMARY KEY,hack_license text,vendor_id text,pickup_datetime timestamp,payment_type text,fare_amount float, surcharge float, mta_tax float,tip_amount float, tolls_amount float,total_amount float)"))
    

    //cx.withSessionDo ( session => session.execute("ALTER TABLE test.trips ALTER pickup_datetime TYPE timestamp"))

    /******* Receive records *******/
    val consumer = new KafkaConsumer[String, String](props)
    consumer.subscribe(Collections.singletonList(topic))

    //val spark: SparkSession = SparkSession.builder().appName("Smack_Kafka_Spark").getOrCreate()

    var liste = scala.collection.immutable.List[String]();
    var nullOffset=0
    while (true) {
      /* Store records in a list */
      val records = consumer.poll(40)

      for (record <- records) {

        liste = record.value() :: liste // to append a new record to the list


        if (liste.size % 200 == 0) {
        	val lines = liste.map(line => line)
        	//val myrdd = spark.sparkContext.makeRDD(lines)
        	val myrdd = sc.makeRDD(lines)
	    	val inputDF = myrdd.flatMap{ line =>
	      	val record = line.split(",")
	      	//val format = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss") 
	      	if (record.length == 11)
	        	Some(Activity(record(0), record(1), record(2),record(3), record(4), record(5).toFloat, record(6).toFloat, record(7).toFloat, record(8).toFloat, record(9).toFloat, record(10).toFloat))
	      	else
	        	None
	    	}.toDF()

	    	val df = inputDF.select(inputDF("medallion"), inputDF("hack_license"), inputDF("vendor_id"), inputDF("pickup_datetime"), inputDF("payment_type"), inputDF("fare_amount"), inputDF("surcharge"), inputDF("mta_tax"), inputDF("tip_amount"), inputDF("tolls_amount"), inputDF("total_amount")).cache()

	    	//df.registerTempTable("activity")
	    	//val medallionTable = sqlContext.sql("SELECT  * FROM activity ".stripMargin)

	    
	    
	    	//medallionTable.foreach(line => println(line))
        println("**************** Persesting 200 lines ********************")
	    	df.write.mode("append").format("org.apache.spark.sql.cassandra").options(Map( "table" -> "trips", "keyspace" -> "test")).save()
	    	liste = scala.collection.immutable.List[String]();
        }

      }
      
      /* Process records here */
      //val lines = liste.map(line => line)

      //println("lines:"+lines);

      //val myrdd = spark.sparkContext.makeRDD(lines);

      //myrdd.collect().foreach(println)
      
      //I didn't close the consumer so as to allow the consumer to receive any new records.
      //consumer.close()
    }
  }
}