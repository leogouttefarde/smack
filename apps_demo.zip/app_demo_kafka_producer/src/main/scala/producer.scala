

import java.util.Properties


import org.apache.kafka.clients.producer.{KafkaProducer, Producer, ProducerConfig, ProducerRecord}

import scala.util.Random

object ProducerTest extends App {
  
  

  //val lines = scala.io.Source.fromFile("/home/xnet/test-small.csv").getLines().toArray
  val lines = scala.io.Source.fromFile("/home/xnet/test-small.csv").getLines()
  val topic = "lol"
  val props = new Properties()

  props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "213.32.72.245:31000,213.32.72.62:31000,213.32.79.191:31000")
  props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
  props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
  props.put(ProducerConfig.ACKS_CONFIG, "all")
  props.put(ProducerConfig.CLIENT_ID_CONFIG, "Producer")

  val kafkaProducer: Producer[Nothing, String] = new KafkaProducer[Nothing, String](props)
  println(kafkaProducer.partitionsFor(topic))
  var cpt = 0
  //for (fileCount <- 1 to lines.length-1) {
    lines.next()
    while(lines.hasNext){
    //val fw = new FileWriter(filePath, true)

    // introduce some randomness to time increments for demo purposes
    





      //var line = lines(fileCount)
      var line = lines.next()
      val producerRecord = new ProducerRecord(topic, line)
      kafkaProducer.send(producerRecord)
      //fw.write(line)

      
      println(s"Sent  messages :  $line")
      val sleeping = 10
      println(s"Sleeping for $sleeping ms")
      Thread sleep sleeping
      cpt = cpt + 1

      if(cpt % 200 == 0){ 
        println(" \n******* "+ cpt +" lines are sent so far\n")
        //Thread sleep 5000
      }

    }

    
  

  kafkaProducer.close()
}