package batch

import com.datastax.spark.connector._
import com.datastax.spark.connector.cql._ 
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.sql.{SaveMode, SQLContext}
import org.apache.spark.SparkFiles
import domain._


object SelectJob {
  def main (args: Array[String]): Unit = {

    // get spark configuration
    val conf = new SparkConf().setAppName("Select with Spark")

    

    // setup spark context
    val sc = new  SparkContext(conf)
    implicit val sqlContext = new SQLContext(sc)

    import org.apache.spark.sql.functions._
    import sqlContext.implicits._

    val cx = com.datastax.spark.connector.cql.CassandraConnector(sc.getConf)
    cx.withSessionDo ( session => session.execute("ALTER TABLE test.trips ALTER pickup_datetime TYPE timestamp"))

    cx.withSessionDo ( session => session.execute("CREATE TABLE IF NOT EXISTS test.paymentType (payment_type text PRIMARY KEY,revenue float,nbr_transactions int)"))
    cx.withSessionDo ( session => session.execute("CREATE TABLE IF NOT EXISTS test.vendorCA (vendor_id text PRIMARY KEY,revenue float)"))
    cx.withSessionDo ( session => session.execute("CREATE TABLE IF NOT EXISTS test.meanTransactionVendor (vendor_id text PRIMARY KEY,meanTransactionVendor float)"))
    cx.withSessionDo ( session => session.execute("CREATE TABLE IF NOT EXISTS test.margePayment (vendor_id text PRIMARY KEY,short_trip int,medium_trip int,long_trip int)"))
    cx.withSessionDo ( session => session.execute("CREATE TABLE IF NOT EXISTS test.resultTotalMonth ( Month int PRIMARY KEY,Revenue_Month float)"))
    
    // initialize input RDD
    

    val df = sqlContext.read.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "trips", "keyspace" -> "test" )).load()
    
    df.registerTempTable("trips")

    val paymentType = sqlContext.sql("SELECT  payment_type,SUM(total_amount) as revenue,COUNT(*) as nbr_transactions FROM trips GROUP BY payment_type".stripMargin)
    
    val vendorCA = sqlContext.sql("SELECT  vendor_id,SUM(total_amount) as revenue FROM trips GROUP BY vendor_id".stripMargin)
    
    val meanTransactionVendor = sqlContext.sql("SELECT  vendor_id,AVG(total_amount) as meantransactionvendor FROM trips GROUP BY vendor_id".stripMargin)
    val totalMonth = sqlContext.sql("SELECT  total_amount,pickup_datetime FROM trips".stripMargin)

    val margePayment = sqlContext.sql("""SELECT
                                            vendor_id,
                                            sum(case when total_amount < 5 then 1 else 0 end) as short_trip,
                                            sum(case when total_amount >= 5 and total_amount < 20 then 1 else 0 end) as medium_trip,
                                            sum(case when total_amount >=20 then 1 else 0 end) as long_trip
                                            from trips
                                            group by vendor_id""")
    //paymentType.show
    //vendorCA.show
    //margePayment.show

    import org.apache.spark.sql.functions.{year,sum,month}
    val resultTotalMonth = totalMonth.groupBy(month(totalMonth("pickup_datetime")).alias("month")).agg(sum("total_amount").alias("revenue_month"))
    //resultTotalYear.show

    
    paymentType.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save("stat/paymentType")
    vendorCA.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save("stat/vendorCA")
    margePayment.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save("stat/margePayment")
    resultTotalMonth.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save("stat/resultTotalMonth")
    meanTransactionVendor.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save("stat/meanTransactionVendor")
    



    paymentType.write.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "paymenttype", "keyspace" -> "test")).save()
    vendorCA.write.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "vendorca", "keyspace" -> "test")).save()
    margePayment.write.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "margepayment", "keyspace" -> "test")).save()
    resultTotalMonth.write.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "resulttotalmonth", "keyspace" -> "test")).save()
    meanTransactionVendor.write.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "meantransactionvendor", "keyspace" -> "test")).save()
           
    //medallionTable.foreach(line => println(line))

    //val cx = com.datastax.spark.connector.cql.CassandraConnector(sc.getConf)
    //cx.withSessionDo ( session => session.execute("CREATE KEYSPACE test WITH replication={'class':'SimpleStrategy', 'replication_factor':3}"))
    //cx.withSessionDo ( session => session.execute("CREATE KEYSPACE test WITH replication = {'class': 'NetworkTopologyStrategy', '202':3,'32':3}  AND durable_writes = true"))
    //cx.withSessionDo ( session => session.execute("CREATE TABLE test.trips (medallion text PRIMARY KEY,hack_license text,vendor_id text,pickup_datetime text,payment_type text,fare_amount float, surcharge float, mta_tax float,tip_amount float, tolls_amount float,total_amount float)"))
    //medallionTable.write.format("org.apache.spark.sql.cassandra").options(Map( "table" -> "trips", "keyspace" -> "test")).save()

  }
}
